const DB_NAME="DiegoCocinaCasaDB", DB_VERSION=1;
let db, products=[], sales=[], photoData="";
const $=id=>document.getElementById(id);
const money=n=>new Intl.NumberFormat("es-CO",{style:"currency",currency:"COP",maximumFractionDigits:0}).format(n||0);
const today=()=>new Date().toISOString().slice(0,10);
function openDB(){return new Promise((resolve,reject)=>{const req=indexedDB.open(DB_NAME,DB_VERSION);req.onupgradeneeded=()=>{const d=req.result;if(!d.objectStoreNames.contains("products"))d.createObjectStore("products",{keyPath:"id"});if(!d.objectStoreNames.contains("sales"))d.createObjectStore("sales",{keyPath:"id"});};req.onsuccess=()=>resolve(req.result);req.onerror=()=>reject(req.error);});}
function store(name,mode="readonly"){return db.transaction(name,mode).objectStore(name);}
function all(name){return new Promise((res,rej)=>{const r=store(name).getAll();r.onsuccess=()=>res(r.result);r.onerror=()=>rej(r.error);});}
function put(name,obj){return new Promise((res,rej)=>{const r=store(name,"readwrite").put(obj);r.onsuccess=()=>res();r.onerror=()=>rej(r.error);});}
function del(name,id){return new Promise((res,rej)=>{const r=store(name,"readwrite").delete(id);r.onsuccess=()=>res();r.onerror=()=>rej(r.error);});}
async function refresh(){products=await all("products");sales=await all("sales");renderAll();}
function toast(msg){const t=$("toast");t.textContent=msg;t.classList.add("show");setTimeout(()=>t.classList.remove("show"),2600);}
function go(view){document.querySelectorAll(".view").forEach(v=>v.classList.toggle("active",v.id===view));document.querySelectorAll(".nav-item").forEach(b=>b.classList.toggle("selected",b.dataset.view===view));window.scrollTo(0,0);}
document.querySelectorAll("[data-view]").forEach(b=>b.addEventListener("click",()=>go(b.dataset.view)));
document.querySelectorAll("[data-go]").forEach(b=>b.addEventListener("click",()=>go(b.dataset.go)));
document.querySelectorAll("[data-close]").forEach(b=>b.addEventListener("click",()=>$(b.dataset.close).close()));
$("todayLabel").textContent=new Intl.DateTimeFormat("es-CO",{day:"numeric",month:"short",year:"numeric"}).format(new Date());
$("saleDate").value=today();

function statusClass(s){return s==="Disponible"?"available":s==="Agotado"?"soldout":"soon";}
function renderAll(){renderDashboard();renderProducts();renderInventory();renderClients();renderHistory();populateSelects();}
function renderDashboard(){
 const total=sales.reduce((a,s)=>a+s.total,0),paid=sales.filter(s=>s.payment==="Pagado").reduce((a,s)=>a+s.total,0),pending=total-paid,units=products.reduce((a,p)=>a+p.stock,0);
 $("statSales").textContent=money(total);$("statPaid").textContent=money(paid);$("statPending").textContent=money(pending);$("statUnits").textContent=units;
 const recent=[...sales].sort((a,b)=>b.created-a.created).slice(0,4);
 $("recentSales").className="stack"+(recent.length?"":" empty");
 $("recentSales").innerHTML=recent.length?recent.map(s=>`<div class="row-card"><div><strong>${esc(s.product)}</strong><small>${esc(s.client||"Cliente sin nombre")} · ${s.date}</small></div><div class="row-actions"><strong>${money(s.total)}</strong><span class="pill ${s.payment==="Pagado"?"available":"soon"}">${s.payment}</span></div></div>`).join(""):"Todavía no hay ventas registradas.";
 const list=products.slice(0,5);$("availabilityList").className="stack"+(list.length?"":" empty");
 $("availabilityList").innerHTML=list.length?list.map(p=>`<div class="row-card"><div><strong>${esc(p.name)}</strong><small>${p.stock} unidades · ${money(p.price)}</small></div><span class="pill ${statusClass(p.status)}">${p.status}</span></div>`).join(""):"Agrega tu primer producto para comenzar.";
}
function renderProducts(){
 const el=$("productList");el.className="product-grid"+(products.length?"":" empty");
 el.innerHTML=products.length?products.map(p=>`<article class="product-card"><div class="product-photo" ${p.photo?`style="background-image:url('${p.photo}')"`:""}>${p.photo?"": "Fotografía del producto"}</div><div class="product-body"><h3>${esc(p.name)}</h3><p>${esc(p.description||"Sin descripción")}</p><div class="price">${money(p.price)}</div><div class="card-foot"><span class="pill ${statusClass(p.status)}">${p.status}</span><button class="small-btn" data-edit="${p.id}">Editar</button></div><div class="card-foot"><small class="muted">${p.stock} unidades</small><button class="small-btn" data-delete="${p.id}">Eliminar</button></div></div></article>`).join(""):"Aún no has agregado productos.";
 el.querySelectorAll("[data-edit]").forEach(b=>b.onclick=()=>editProduct(Number(b.dataset.edit)));
 el.querySelectorAll("[data-delete]").forEach(b=>b.onclick=()=>deleteProduct(Number(b.dataset.delete)));
}
function renderInventory(){
 $("inventoryList").className="stack"+(products.length?"":" empty");
 $("inventoryList").innerHTML=products.length?products.map(p=>`<div class="row-card"><div><strong>${esc(p.name)}</strong><small>${p.status} · ${money(p.price)}</small></div><div class="row-actions"><strong>${p.stock} un.</strong><button class="small-btn" data-add="${p.id}">＋ Stock</button></div></div>`).join(""):"No hay productos en inventario.";
 $("inventoryList").querySelectorAll("[data-add]").forEach(b=>b.onclick=()=>{$("stockProduct").value=b.dataset.add;$("stockQty").focus();});
}
function renderClients(){
 const map=new Map();sales.forEach(s=>{const name=s.client.trim();if(!name)return;const v=map.get(name)||{total:0,pending:0,count:0};v.total+=s.total;if(s.payment==="Pendiente")v.pending+=s.total;v.count++;map.set(name,v);});
 const entries=[...map.entries()].sort((a,b)=>b[1].pending-a[1].pending);
 $("clientList").className="stack"+(entries.length?"":" empty");
 $("clientList").innerHTML=entries.length?entries.map(([name,v])=>`<article class="panel"><h3>${esc(name)}</h3><p class="muted">${v.count} pedido(s) · Total comprado: <strong>${money(v.total)}</strong></p><div class="row-card"><span>Saldo pendiente</span><strong>${money(v.pending)}</strong></div></article>`).join(""):"Los clientes aparecerán al registrar sus pedidos.";
}
function renderHistory(){
 const q=$("historySearch").value.toLowerCase();
 const list=[...sales].sort((a,b)=>b.created-a.created).filter(s=>(s.client+" "+s.product).toLowerCase().includes(q));
 $("historyList").className="stack"+(list.length?"":" empty");
 $("historyList").innerHTML=list.length?list.map(s=>`<article class="panel"><div class="row-card" style="padding:0;border:0"><div><strong>${esc(s.product)}</strong><small>${esc(s.client||"Cliente sin nombre")} · ${s.date}</small></div><span class="pill ${s.payment==="Pagado"?"available":"soon"}">${s.payment}</span></div><p class="muted">${s.qty} × ${money(s.unitPrice)} = <strong>${money(s.total)}</strong></p><button class="small-btn" data-payment="${s.id}">${s.payment==="Pagado"?"Cambiar a pendiente":"Registrar como pagado"}</button></article>`).join(""):"No hay operaciones que coincidan.";
 $("historyList").querySelectorAll("[data-payment]").forEach(b=>b.onclick=()=>openPayment(Number(b.dataset.payment)));
}
function populateSelects(){
 const stock=$("stockProduct"),sale=$("saleProduct"),oldStock=stock.value,oldSale=sale.value;
 stock.innerHTML='<option value="">Selecciona un producto</option>'+products.map(p=>`<option value="${p.id}">${esc(p.name)} · ${p.stock} unidades</option>`).join("");
 sale.innerHTML='<option value="">Selecciona un producto</option>'+products.filter(p=>p.status==="Disponible"&&p.stock>0).map(p=>`<option value="${p.id}">${esc(p.name)} · ${money(p.price)} · Stock ${p.stock}</option>`).join("");
 if(products.some(p=>String(p.id)===oldStock))stock.value=oldStock;if(products.some(p=>String(p.id)===oldSale&&p.status==="Disponible"&&p.stock>0))sale.value=oldSale;
 const names=[...new Set(sales.map(s=>s.client).filter(Boolean))];$("clientOptions").innerHTML=names.map(n=>`<option value="${esc(n)}"></option>`).join("");
 updateSaleTotal();
}
function updateSaleTotal(){const p=products.find(x=>x.id===Number($("saleProduct").value));$("saleTotal").textContent=money((p?.price||0)*(Number($("saleQty").value)||0));}
$("saleProduct").addEventListener("change",updateSaleTotal);$("saleQty").addEventListener("input",updateSaleTotal);
$("newProductBtn").onclick=()=>openProduct();
function openProduct(p=null){$("productForm").reset();$("productId").value=p?.id||"";$("productDialogTitle").textContent=p?"Editar producto":"Nuevo producto";$("productName").value=p?.name||"";$("productDescription").value=p?.description||"";$("productPrice").value=p?.price??"";$("productStock").value=p?.stock??0;$("productStatus").value=p?.status||"Disponible";photoData=p?.photo||"";previewPhoto();$("productPhoto").value="";$("productDialog").showModal();}
function editProduct(id){const p=products.find(x=>x.id===id);if(p)openProduct(p);}
async function deleteProduct(id){if(!confirm("¿Eliminar este producto del catálogo? El historial de ventas se conservará."))return;await del("products",id);await refresh();toast("Producto eliminado.");}
$("productPhoto").addEventListener("change",e=>{const f=e.target.files[0];if(!f)return;if(f.size>5*1024*1024){toast("La fotografía debe pesar menos de 5 MB.");e.target.value="";return;}const reader=new FileReader();reader.onload=()=>{const img=new Image();img.onload=()=>{const c=document.createElement("canvas"),max=1000,scale=Math.min(1,max/Math.max(img.width,img.height));c.width=Math.round(img.width*scale);c.height=Math.round(img.height*scale);c.getContext("2d").drawImage(img,0,0,c.width,c.height);photoData=c.toDataURL("image/jpeg",.78);previewPhoto();};img.src=reader.result;};reader.readAsDataURL(f);});
function previewPhoto(){$("photoPreview").style.backgroundImage=photoData?`url("${photoData}")`:"";$("photoPreview").textContent=photoData?"":"Vista previa de la fotografía";}
$("productForm").addEventListener("submit",async e=>{e.preventDefault();const id=$("productId").value?Number($("productId").value):Date.now();const old=products.find(p=>p.id===id);const stock=Number($("productStock").value);let status=$("productStatus").value;if(stock===0&&status==="Disponible")status="Agotado";const p={id,name:$("productName").value.trim(),description:$("productDescription").value.trim(),price:Number($("productPrice").value),stock,status,photo:photoData};await put("products",p);$("productDialog").close();await refresh();toast(old?"Producto actualizado.":"Producto agregado al catálogo.");});
$("stockForm").addEventListener("submit",async e=>{e.preventDefault();const id=Number($("stockProduct").value),qty=Number($("stockQty").value),p=products.find(x=>x.id===id);if(!p||qty<1)return;p.stock+=qty;if(p.status==="Agotado")p.status="Disponible";await put("products",p);$("stockQty").value=1;await refresh();toast("Existencias actualizadas.");});
$("saleForm").addEventListener("submit",async e=>{e.preventDefault();const p=products.find(x=>x.id===Number($("saleProduct").value)),qty=Number($("saleQty").value);if(!p||qty<1||qty>p.stock){toast("Revisa el producto y las existencias disponibles.");return;}const s={id:Date.now(),created:Date.now(),date:$("saleDate").value,client:$("saleClient").value.trim(),product:p.name,productId:p.id,qty,unitPrice:p.price,total:p.price*qty,payment:document.querySelector('input[name="payment"]:checked').value};p.stock-=qty;if(p.stock===0)p.status="Agotado";await put("products",p);await put("sales",s);$("saleClient").value="";$("saleQty").value=1;$("saleProduct").value="";await refresh();go("history");toast("Venta registrada e inventario actualizado.");});
function openPayment(id){const s=sales.find(x=>x.id===id);if(!s)return;$("paymentSaleId").value=id;$("paymentDescription").textContent=`${s.client||"Cliente sin nombre"} · ${s.product} · ${money(s.total)}`;$("paymentStatus").value=s.payment==="Pagado"?"Pendiente":"Pagado";$("saleDialog").showModal();}
$("paymentForm").addEventListener("submit",async e=>{e.preventDefault();const id=Number($("paymentSaleId").value),s=sales.find(x=>x.id===id);if(!s)return;s.payment=$("paymentStatus").value;await put("sales",s);$("saleDialog").close();await refresh();toast("Estado del pago actualizado.");});
$("historySearch").addEventListener("input",renderHistory);
$("exportBtn").onclick=async()=>{const data={app:"Diego cocina en casa",version:1,exportedAt:new Date().toISOString(),products:await all("products"),sales:await all("sales")};const blob=new Blob([JSON.stringify(data)],{type:"application/json"});download(blob,`respaldo-diego-cocina-${today()}.json`);toast("Copia de seguridad descargada.");};
$("importFile").addEventListener("change",async e=>{const f=e.target.files[0];if(!f)return;try{const data=JSON.parse(await f.text());if(!Array.isArray(data.products)||!Array.isArray(data.sales))throw Error("Archivo no válido");if(!confirm("Esto reemplazará los datos actuales. ¿Deseas continuar?"))return;const tx=db.transaction(["products","sales"],"readwrite");tx.objectStore("products").clear();tx.objectStore("sales").clear();data.products.forEach(p=>tx.objectStore("products").put(p));data.sales.forEach(s=>tx.objectStore("sales").put(s));tx.oncomplete=async()=>{await refresh();toast("Copia restaurada correctamente.");};tx.onerror=()=>toast("No se pudo restaurar la copia.");}catch(err){toast("El archivo seleccionado no es una copia válida.");}e.target.value="";});
function download(blob,name){const url=URL.createObjectURL(blob),a=document.createElement("a");a.href=url;a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);}
function esc(s){return String(s??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));}
let deferredPrompt;
window.addEventListener("beforeinstallprompt",e=>{e.preventDefault();deferredPrompt=e;$("installBtn").hidden=false;});
$("installBtn").onclick=async()=>{if(!deferredPrompt)return;deferredPrompt.prompt();await deferredPrompt.userChoice;deferredPrompt=null;$("installBtn").hidden=true;};
// Primera etapa de integración: autenticación Supabase y lectura del perfil/rol.
const SUPABASE_URL = "https://nidkljhagbauuorhpwns.supabase.co";
const SUPABASE_PUBLISHABLE_KEY = "sb_publishable_CNFbNoF1SySXHdBHp4seiA_4pcZRbPQ";
let supabaseClient = null;
function authMessage(message){$("authMessage").textContent=message||"";}
function showAuthenticated(profile,email){
  $("authGate").hidden=true;$("appShell").hidden=false;
  $("userRole").hidden=false;$("logoutBtn").hidden=false;
  $("userRole").textContent=(profile.role==="admin"?"ADMINISTRADOR":"VENDEDOR")+" · "+(profile.full_name||email);
}
async function startAuthenticatedApp(){
  db=await openDB();await refresh();
  if("serviceWorker" in navigator&&location.protocol.startsWith("http"))navigator.serviceWorker.register("./sw.js").catch(()=>{});
}
async function verifySession(session){
  if(!session){$("authGate").hidden=false;$("appShell").hidden=true;return;}
  const {data,error}=await supabaseClient.from("profiles").select("id,full_name,role").eq("id",session.user.id).single();
  if(error||!data){await supabaseClient.auth.signOut();$("authGate").hidden=false;$("appShell").hidden=true;authMessage("No se pudo validar tu perfil. Revisa que el usuario tenga un perfil activo.");return;}
  showAuthenticated(data,session.user.email||"");
  await startAuthenticatedApp();
}
$("loginForm").addEventListener("submit",async e=>{
  e.preventDefault();authMessage("Verificando acceso…");
  const {data,error}=await supabaseClient.auth.signInWithPassword({email:$("loginEmail").value.trim(),password:$("loginPassword").value});
  if(error){authMessage("No se pudo iniciar sesión. Verifica el correo y la contraseña.");return;}
  try{await verifySession(data.session);authMessage("");}catch(err){console.error(err);authMessage("No se pudo cargar la aplicación. Comprueba tu conexión.");}
});
$("logoutBtn").onclick=async()=>{await supabaseClient.auth.signOut();location.reload();};
(async()=>{
  try{
    if(!window.supabase?.createClient)throw new Error("No se pudo cargar el cliente de conexión.");
    supabaseClient=window.supabase.createClient(SUPABASE_URL,SUPABASE_PUBLISHABLE_KEY);
    const {data,error}=await supabaseClient.auth.getSession();if(error)throw error;
    await verifySession(data.session);
  }catch(e){console.error(e);$("authGate").hidden=false;$("appShell").hidden=true;authMessage("No se pudo conectar. Revisa Internet e inténtalo nuevamente.");}
})();