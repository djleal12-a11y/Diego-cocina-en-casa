DIEGO COCINA EN CASA — PROYECTO ANDROID (ETAPA 1: ACCESO)

Esta versión agrega:
- Permiso de Internet en Android.
- Inicio de sesión con Supabase Auth.
- Validación del perfil del usuario en public.profiles.
- Visualización del rol ADMINISTRADOR o VENDEDOR.
- Cierre de sesión.

Configuración ya incluida:
- Supabase URL del proyecto.
- Publishable key (clave pública, apta para cliente).

IMPORTANTE: esta es una compilación de prueba de AUTENTICACIÓN. El catálogo, inventario y ventas todavía usan el almacenamiento local IndexedDB. AÚN NO hay sincronización de productos, ventas, pagos ni inventario entre dispositivos. Tampoco están aplicadas todavía las restricciones visuales de vendedor dentro de cada pantalla. No usar para operación real ni borrar la app anterior.

Para compilar:
- Subir el contenido de esta carpeta a GitHub conservando la estructura.
- Ejecutar el workflow Build Android APK.
- Descargar el artefacto Diego-cocina-en-casa-APK.

Requiere Internet para cargar Supabase y validar la sesión.
