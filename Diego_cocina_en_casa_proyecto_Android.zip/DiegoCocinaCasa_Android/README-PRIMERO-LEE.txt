DIEGO COCINA EN CASA — PROYECTO ANDROID

Este paquete convierte la aplicación web original en una app Android empaquetada.
Incluye los archivos de la app dentro del APK, por lo que no necesita Netlify ni conexión para abrir la pantalla principal. Los datos se guardan localmente en el dispositivo mediante IndexedDB.

IMPORTANTE: este paquete es el PROYECTO FUENTE, no un APK ya compilado. Para producir el APK se debe ejecutar la compilación Android (Android SDK/Gradle). El flujo incluido en .github/workflows/build-apk.yml permite hacerlo en GitHub Actions.

SALIDA DE LA COMPILACIÓN:
app/build/outputs/apk/debug/app-debug.apk

Para compilar en un computador con Android SDK y Java 17:
  gradle assembleDebug

El APK debug es para instalación directa y pruebas; no está firmado para distribución comercial en Play Store.

Privacidad y datos:
- No hay cuentas ni sincronización entre dispositivos.
- Productos, fotos y ventas quedan almacenados localmente en el dispositivo.
- Exporta respaldos desde la sección Más > Respaldo.
